# OneKiwi's KiCad Addon Package Repository

## Installation 💾

Add our custom repo to **the Plugin and Content Manager**, the URL is `https://raw.githubusercontent.com/OneKiwiTech/onekiwi-kicad-repository/main/repository.json`

![pcm](image/pcm.png)

From there you can install the plugin via the GUI.