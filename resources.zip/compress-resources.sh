#!/bin/bash

cd resources
zip -r resources.zip ./
cd ../
mv resources/resources.zip resources.zip