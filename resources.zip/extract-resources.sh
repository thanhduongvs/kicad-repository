#!/bin/bash

unzip resources.zip -d resources